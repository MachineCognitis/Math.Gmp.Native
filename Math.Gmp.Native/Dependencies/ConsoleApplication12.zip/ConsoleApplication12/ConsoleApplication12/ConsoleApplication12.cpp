// ConsoleApplication12.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "gmp.h"


int main()
{
	mpz_t x, y, z;
	mpz_init_set_ui(x, 1000);
	mpz_init_set_ui(y, 2000);
	mpz_init(z);

	mpz_add(z, x, y);

    return 0;
}

